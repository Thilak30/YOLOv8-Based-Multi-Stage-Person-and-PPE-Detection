# PersonDetection > 2025-03-14 9:53am
https://universe.roboflow.com/r-thanuja-reddy-yt93m/persondetection-bgsqe

Provided by a Roboflow user
License: CC BY 4.0

